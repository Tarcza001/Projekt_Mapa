﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Windows;
using System.Windows.Forms.Integration;

namespace AplikacjaMapy
{
    public partial class MainWindow : Window
    {
        void Log(string message)
        {
            string logPath = "log.txt"; // Plik logów w katalogu aplikacji
            string logMessage = $"{DateTime.Now}: {message}";

            File.AppendAllText(logPath, logMessage + Environment.NewLine);
        }

        private GMapControl gmap = new GMapControl();
        private GMapOverlay markersOverlay = new GMapOverlay("markers");
        private GMapOverlay routeOverlay = new GMapOverlay("route");
        private GMarkerGoogle startMarker = null;
        private GMarkerGoogle endMarker = null;
        private bool isStartPointSet = false;

        public MainWindow()
        {
            InitializeComponent();
            InitializeMap();
        }

        private void InitializeMap()
        {
            // Tworzenie kontrolki mapy
            gmap = new GMapControl
            {
                Dock = DockStyle.Fill,
                MapProvider = GMapProviders.OpenStreetMap, // OpenStreetMap jako dostawca
                MinZoom = 1,
                MaxZoom = 18,
                Zoom = 10,
                Position = new PointLatLng(50.0614, 19.9383), // Kraków jako startowa lokalizacja 
                ShowCenter = false
            };

            // Dodanie mapy do kontenera   
            WindowsFormsHost host = new WindowsFormsHost();
            host.Child = gmap;
            this.Content = host;

            // Tworzenie warstwy z markerami i trasą   
            markersOverlay = new GMapOverlay("markers");
            routeOverlay = new GMapOverlay("route");
            
            gmap.Overlays.Add(markersOverlay);
            gmap.Overlays.Add(routeOverlay);

            // Obsługa kliknięć na mapie
            gmap.MouseClick += Gmap_OnMapClick;

            //Przemieszczenie po mapie
            gmap.DragButton = MouseButtons.Middle;
        }
        private async void Gmap_OnMapClick(object? sender, System.Windows.Forms.MouseEventArgs e)
        {
            //pobieranie wspolrzednych klikniecia
            PointLatLng point = gmap.FromLocalToLatLng(e.X, e.Y);
            Log($" Współrzędne kliknięcia: {point.Lat}, {point.Lng}");
            if (e.Button == MouseButtons.Left)
            {
                if (!isStartPointSet)
                {
                    // Ustawienie punktu startowego
                    if (startMarker != null)
                    {
                        markersOverlay.Markers.Remove(startMarker);
                    }
                    startMarker = new GMarkerGoogle(point, GMarkerGoogleType.green);
                    startMarker.ToolTipText = "Punkt startowy";
                    markersOverlay.Markers.Add(startMarker);
                    isStartPointSet = true;
                }
                else
                {
                    // Ustawienie punktu końcowego
                    if (endMarker != null)
                    {
                        markersOverlay.Markers.Remove(endMarker);
                    }
                    endMarker = new GMarkerGoogle(point, GMarkerGoogleType.red);
                    endMarker.ToolTipText = "Punkt końcowy";
                    markersOverlay.Markers.Add(endMarker);

                    // Pobieranie trasy i rysowanie jej
                    List<PointLatLng> route = await GetRouteFromAPI(startMarker.Position, endMarker.Position);
                    if (route != null)
                    {
                        DrawRouteOnMap(route);
                    }
                    // Resetowanie wyboru
                    isStartPointSet = false;
                }
            }
            else if(e.Button == MouseButtons.Right)
            {
                // Usunięcie wszystkich markerów i tras
                markersOverlay.Markers.Clear();
                var routeOverlay = gmap.Overlays.FirstOrDefault(o => o.Id == "route");
                if (routeOverlay != null)
                {
                    gmap.Overlays.Remove(routeOverlay);
                }
                gmap.Refresh();

                // Resetowanie zmiennych
                startMarker = null;
                endMarker = null;
                isStartPointSet = false;
            }
        }
        private void ClearMarkers()
        {
            Log("Czyszczenie mapy");
            if (startMarker != null)
            {
                markersOverlay.Markers.Remove(startMarker);
                startMarker = null;
            }

            if (endMarker != null)
            {
                markersOverlay.Markers.Remove(endMarker);
                endMarker = null;
            }

            // Resetujemy flagę wyboru punktu startowego
            isStartPointSet = false;

            // Czyścimy również rysowane trasy, jeśli były dodane
            markersOverlay.Markers.Clear();
            routeOverlay.Routes.Clear();
            gmap.Refresh();
        }
        private async Task<List<PointLatLng>> GetRouteFromAPI(PointLatLng start, PointLatLng end)
        {   // Tworzenie URL do zapytania API OSRM dla trybu driving (jazda samochodem)
            string url = $"http://router.project-osrm.org/route/v1/driving/" +
                $"{start.Lng.ToString(CultureInfo.InvariantCulture)},{start.Lat.ToString(CultureInfo.InvariantCulture)};" +
                $"{end.Lng.ToString(CultureInfo.InvariantCulture)},{end.Lat.ToString(CultureInfo.InvariantCulture)}" +
                "?overview=full&geometries=geojson";
         
            using (HttpClient client = new HttpClient())
            {   
                HttpResponseMessage response = await client.GetAsync(url); // wysłanie zapytania GET do API OSRM

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();   // odpowiedź OSRM API
                    JObject json = JObject.Parse(jsonResponse);
                    var route = json["routes"]?[0]?["geometry"]?["coordinates"]; // pobieranie współrzednych trasy z odpowiedzi API

                    if (route != null)
                    {
                        List<PointLatLng> points = new List<PointLatLng>(); // lista punktów
                        foreach (var coord in route) 
                        {   //Pobieranie długośici i szerokości geograficznej
                            double? lng = coord[0]?.Value<double>();
                            double? lat = coord[1]?.Value<double>();

                            if (lng.HasValue && lat.HasValue)
                            {
                                points.Add(new PointLatLng(lat.Value, lng.Value)); // dodanie punktów trasy
                            }
                        }
                        return points; 
                    }
                    else{Log(" API nie zwróciło trasy.");}
                }
                else{ Log(" Błąd API OSRM: " + response.StatusCode);}
            }
            return null;
        }

        private void DrawRouteOnMap(List<PointLatLng> routePoints)
        {
            // Rysowanie trasy na mapie
            routeOverlay.Routes.Clear(); // czyszczenie poprzedniej trasy
            gmap.Overlays.Add(routeOverlay);// ponowne dodanie tarsy do mapy
            
            // Tworzenie nowej trasy na podstawie punktów zwróconych przez API
            GMapRoute route = new GMapRoute(routePoints, "Trasa")
            {
                Stroke = new System.Drawing.Pen(System.Drawing.Color.Blue, 4)
            };
            
            //dodanie trasy do mapy
            routeOverlay.Routes.Add(route);
          
            gmap.Refresh();
            Log("Trasa powinna być widoczna na mapie!");
        }
    }
}


